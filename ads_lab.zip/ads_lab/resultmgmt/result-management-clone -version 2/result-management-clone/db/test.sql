create table test(
	id int auto_increment,
    instructor_id int,
    test_date date,
    foreign key(instructor_id) references instructor(id),
    primary key(id)
);

-------------