import React from "react";

function Sregister() {
    return (
        <div>Sregister</div>
    )
}

export default Sregister;