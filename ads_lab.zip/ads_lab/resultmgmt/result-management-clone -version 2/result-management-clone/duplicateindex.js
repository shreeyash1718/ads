
app.post('/teacher-register', function(req, res) {
    const username = req.body.id;
    const password = req.body.name;
  
    // Hash the password before saving it to the database
    const hashedPassword = hashPassword(password);
  
    // Insert the new user into the database

  
    pool.query('INSERT INTO  (username, password, role) VALUES (?, ?, ?)', [username, hashedPassword, role], function(err, results) {
    if (err) {
        // Handle the error and return an error message
        console.log(err);
        res.send({ message: 'An error occurred while registering the user.' });
    }
    else {
        // Return a success message
        console.log("successs");
        res.send({ message: 'teacher registered successfully.' });
    }
    });
  );

