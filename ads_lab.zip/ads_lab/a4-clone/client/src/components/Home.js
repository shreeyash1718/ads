import React from 'react'

const Home = () => {
  return (
    <div className="container">
      <h1 className="title">Quiz App</h1>
      <p className="subtitle">Test your knowledge with our quiz!</p>
    </div>
  );
};

export default Home;



