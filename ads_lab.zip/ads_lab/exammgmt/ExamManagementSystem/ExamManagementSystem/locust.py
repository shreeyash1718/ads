from locust import HttpUser,task

class HelloWorldUser(HttpUser):
    @task
    def hello_world(self):
        self.client.get("/");
        self.client.get("/AddNewQuiz");
        self.client.get("/TeacherViewNew");
        self.client.get("/TeacherViewUpdate");
        self.client.get("/ScoreCard");
        self.client.get("/AllQuizPage");
        self.client.get("/facultyLogin");
        self.client.get("/register");